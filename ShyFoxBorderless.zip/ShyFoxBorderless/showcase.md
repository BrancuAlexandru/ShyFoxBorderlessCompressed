# Videos

[shy-toggles.webm](https://github.com/Naezr/ShyFox/assets/95460152/90bf4860-4200-49fe-aede-9be777f80cb9)                

[shy-floating-panels.webm](https://github.com/Naezr/ShyFox/assets/95460152/eb4de9b8-2268-43c8-b006-53c1494b4ec2)                  

[shy-new-tab.webm](https://github.com/Naezr/ShyFox/assets/95460152/8e7837bf-ce58-4657-a3c6-9edb4b293f3b)      

[shy-pins.webm](https://github.com/Naezr/ShyFox/assets/95460152/851c2ddd-5fc7-465d-a0bd-60b0b755bbe3)
                
[shy-controls.webm](https://github.com/Naezr/ShyFox/assets/95460152/10fc8ea0-c571-44b5-8e69-4e8486c71dc2)

[shy-customize.webm](https://github.com/Naezr/ShyFox/assets/95460152/2029830e-8c20-4dfb-ac54-33a62c07d715)                  

[shy-downloads.webm](https://github.com/Naezr/ShyFox/assets/95460152/f5a4adc2-ee2d-44f0-bc53-44b3b0297792)

[shy-page-load.webm](https://github.com/Naezr/ShyFox/assets/95460152/23aaa483-14ee-4976-9fc6-a6803e3f5826)
